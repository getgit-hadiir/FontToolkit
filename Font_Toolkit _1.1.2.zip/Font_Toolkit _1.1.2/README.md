# FontToolkit (C11)

A C11 console application for inventorying TrueType (`.ttf`) and OpenType (`.otf`) files, extracting common SFNT name-table metadata, and producing renamed/grouped **copies**. Source files are never moved, overwritten, or deleted by the current operations.

## Current features

- Console UI is constrained to a maximum of 41 columns; separators and progress lines use shared UI helpers to prevent line overflow on narrow phone displays.
- Shared base constants are defined in `include/common.h`; source files follow the project source-file header/footer convention.

- First-run workspace setup: `Source`, `Output`, and `User` directories.
- Recursive TTF/OTF discovery, followed by a metadata pass with progress indicators.
- Reads legacy family/subfamily name IDs and prefers typographic family/subfamily IDs when present; also reads full and PostScript names.
- Per-operation SQLite database under `._data/appdata.db`, with font inventory, metadata validity, file size, and copy-action history.
- Timestamped output directory, Markdown operation log (`_log/log.md`), and inventory report named after the output directory (for example `20261022_1546.md`).
- Rename operation uses the font's full name where available, then PostScript name, then source filename.
- Family grouping copies files into sanitized family folders.
- Undo option removes generated copies listed in an operation database, while preserving the database, report, and log. It validates that every deletion target is inside the selected operation folder.
- Output filename collisions receive numeric suffixes rather than overwriting existing files.
- Names over 48 characters are placed in `Long_Names` with a unique short filename and a `.txt` sidecar containing the intended filename and source metadata.
- Reports include file inventory, metadata extraction totals, unknown-family totals, file sizes, and copy success/failure totals.
- Source code, identifiers, and comments are in English.

## Requirements

- CMake 3.16+
- C11 compiler (`clang` is recommended on Termux)
- SQLite3 development package

## Build on Termux

If CMake and SQLite are already installed, ensure the compiler and `pkg-config` are available:

```sh
pkg install clang pkg-config
clang --version
cmake --version
pkg-config --modversion sqlite3
```

Build from the project root:

```sh
./tools/build.sh Release
./tools/build.sh Debug
```

Or use `./tools/build` for a Release build. The build script creates `build_release/` and `build_debug/`. Debug target naming is configured as `fonttoolkitd`; Release is `fonttoolkit`.

If CMake cannot locate SQLite, check `pkg-config --cflags --libs sqlite3` and that the Termux SQLite package is installed. No third-party font library is currently required.

## Run

Run from the project root so the relative configuration file `user/project.conf` is found:

```sh
./build_release/fonttoolkit
```

On first run, enter a workspace path, for example `$HOME/font-workspace`. Put test fonts under its `Source/` folder; nested folders are supported. The program creates `Source`, `Output`, and `User` directories if needed.

## Menu

1. Scan source folder
2. Rename to original font name (copies to output)
3. Group by font family (copies to output)
4. Undo generated copies from an operation folder
X. Exit

## Suggested real-world test with ~2,000 fonts

1. Copy a representative collection into `workspace/Source`, preserving nested folders.
2. Run **Scan** first and inspect the Markdown report and SQLite inventory.
3. Compare the discovered count with an independent filesystem count of `.ttf` and `.otf` files.
4. Review files with unavailable metadata and those grouped as `Unknown`.
5. Run rename and grouping separately; compare success/failure totals and inspect collisions and `Long_Names` sidecars.
6. Re-run each operation and verify that source files remain unchanged and outputs are not overwritten.
7. Keep the operation folder/database/report when investigating an unexpected result.

## Important limitations

- This is a lightweight SFNT name-table reader, not a complete font parser. It does not validate every aspect of font files, fully interpret every legacy Macintosh encoding, or guarantee correct names for every variable/collection font format. Unsupported or malformed metadata is reported as unavailable rather than treated as a reliable name.
- `.ttc` collections and other extensions are not included in the scan; only `.ttf` and `.otf` are scanned.
- A family folder is based on metadata, so family naming differences across font versions can result in separate folders.
- Undo removes generated output copies based on the selected operation database. It does not restore a deleted output copy from elsewhere and does not remove report/database/log files.
- The Markdown report escapes vertical bars in cell values, but unusual Markdown characters may still affect display. The underlying paths remain stored in SQLite/logs.
- Run the app from the project root unless configuration path handling is changed.

## Terminal themes

- Open **5) Interface theme settings** to switch between Dark and Light. The choice is saved for later launches.
- The editable, offline configuration is `user/ui_theme.conf` (relative to the directory from which the app is launched). It stores `[General] theme=dark|light` and independent `[Dark]` / `[Light]` palettes.
- Supported role keys: `background`, `text`, `muted_text`, `accent`, `success`, `warning`, `error`, `border`, `input`, `selection`.
- Supported color identifiers: `BLACK`, `RED`, `GREEN`, `YELLOW`, `BLUE`, `MAGENTA`, `CYAN`, `WHITE`, `GRAY`, `BRIGHT_RED`, `BRIGHT_GREEN`, `BRIGHT_YELLOW`, `BRIGHT_BLUE`, `BRIGHT_MAGENTA`, `BRIGHT_CYAN`, `BRIGHT_WHITE`, `DARK_GREEN`, `DARK_YELLOW`, `DARK_RED`. Values are mapped to standard ANSI terminal colors; terminal emulators may render them differently.
- Missing or invalid individual color values use the built-in default for that role. If the file is missing, a default configuration is created. Use `R) Restore built-in defaults` in the theme menu to reset both palettes and select Dark.
- For monochrome output, applications embedding FontToolkit can call `uifx_set_ansi_enabled(0)`; content and status labels remain available without color.
